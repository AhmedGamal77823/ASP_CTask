﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using backend.Data;
using backend.Models;
using backend.Helpers;
using System.Text;

namespace backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly backendContext _context;

        public UsersController(backendContext context)
        {
            _context = context;
        }

        // GET: api/Users
        [HttpGet]
        public async Task<ActionResult<string>> GetUser()
        {
            Console.WriteLine("Ebcrypting Ahmed");
            var dec = Encryption.Encryprt("Ahmed", "1234");
            Console.WriteLine(dec);
            Console.WriteLine("Decrypt False");
            Console.WriteLine(Encryption.Decrypt(dec, "1234"));
            Console.WriteLine("Decrypt True");
            Console.WriteLine(Encryption.Decrypt(dec, "12348"));


            return "Done";
        }

    }
}
